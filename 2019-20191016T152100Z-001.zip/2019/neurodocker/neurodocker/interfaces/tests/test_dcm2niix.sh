#!/usr/bin/env bash

set -ex

dcm2niix -h

printf 'passed'
