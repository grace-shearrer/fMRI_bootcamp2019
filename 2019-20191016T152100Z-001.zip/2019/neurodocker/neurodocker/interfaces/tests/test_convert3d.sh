#!/usr/bin/env bash

set -ex

c3d -h

printf 'passed'
