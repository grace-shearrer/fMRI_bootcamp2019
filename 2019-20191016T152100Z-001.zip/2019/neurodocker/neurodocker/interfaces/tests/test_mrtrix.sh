#!/usr/bin/env bash

set -ex

mrthreshold --help

printf 'passed'
