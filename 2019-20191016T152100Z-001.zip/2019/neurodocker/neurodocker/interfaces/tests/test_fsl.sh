#!/usr/bin/env bash

set -ex

bet2 -h
flirt -version

printf 'passed'
