#!/usr/bin/env bash

set -ex

which petpvc

printf 'passed'
