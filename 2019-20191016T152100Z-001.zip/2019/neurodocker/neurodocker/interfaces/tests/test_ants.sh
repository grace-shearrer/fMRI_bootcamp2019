#!/usr/bin/env bash

set -ex

Atropos --help
antsRegistration --version

printf 'passed'
