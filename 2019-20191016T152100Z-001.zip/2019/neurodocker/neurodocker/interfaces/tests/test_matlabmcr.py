"""Tests for neurodocker.interfaces.MatlabMCR"""
