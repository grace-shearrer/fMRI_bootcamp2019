#!/usr/bin/env bash

set -ex

3dSkullStrip -help

printf 'passed'
