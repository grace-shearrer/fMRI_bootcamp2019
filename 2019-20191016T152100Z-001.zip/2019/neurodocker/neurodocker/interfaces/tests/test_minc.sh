#!/usr/bin/env bash

set -ex

mincresample -version

printf 'passed'
